# 🔥 Fire.X - Hacker Playground

Welcome to **Fire.X**! This is a hacker-themed AI & gaming platform for educational and entertainment purposes.

## Features
- Demo login system (browser-only)
- Matrix code rain mini-game
- Typing challenge mini-game
- Number code cracker mini-game
- AI generated images gallery
- Built-in search engine (Google search)
- Futuristic hacker aesthetic

## Hacker Disclaimer
**WARNING:** Fire.X is experimental. Unauthorized use may lead to data loss, AI chaos, or corrupted game progress.
Use at your own risk. The developers are not liable for misuse or unintended outcomes.
